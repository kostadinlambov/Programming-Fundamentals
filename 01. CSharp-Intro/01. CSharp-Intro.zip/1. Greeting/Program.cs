﻿namespace _1.Greeting
{
    using System;
    public class Program
    {
        public static void Main()
        {
            var name = Console.ReadLine();
            Console.WriteLine($"Hello, {name}!");
        }
    }
}
