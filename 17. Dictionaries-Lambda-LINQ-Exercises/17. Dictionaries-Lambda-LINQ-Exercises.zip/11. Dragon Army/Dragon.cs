﻿//public class Dragon
//{
//    //public string DragonName { get; set; }
//    public decimal DragonDamage { get; set; }
//    public decimal DragonHealth { get; set; }
//    public decimal DragonArmor { get; set; }

//}

