﻿using System;

public class Practice_Floating_Point_Numbers
{
    public static void Main()
    {
        decimal num1 = 3.141592653589793238m;
        double num2 = 1.60217657;
        decimal num3 = 7.8184261974584555216535342341m;

        Console.WriteLine(num1);
        Console.WriteLine(num2);
        Console.WriteLine(num3);
    }
}