﻿using System;

public class Practice_Characters_and_Strings
{
    public static void Main()
    {
        string firstString = "Software University";
        char firstLetter = 'B';
        char secondLetter = 'y';
        char thirdLetter = 'e';
        string secondString = "I love programming";

        Console.WriteLine(firstString);
        Console.WriteLine(firstLetter);
        Console.WriteLine(secondLetter);
        Console.WriteLine(thirdLetter);
        Console.WriteLine(secondString);
    }
}
