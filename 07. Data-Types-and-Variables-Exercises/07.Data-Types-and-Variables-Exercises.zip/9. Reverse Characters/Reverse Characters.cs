﻿using System;

public class Reverse_Characters
{
    public static void Main()
    {
        var firstLetter = Console.ReadLine();
        var secondLetter = Console.ReadLine();
        var thirdLetter = Console.ReadLine();

        Console.WriteLine(thirdLetter + secondLetter + firstLetter);
    }
}